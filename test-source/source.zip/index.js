console.log('Hello from CI/CD Pipeline!');
