# CI/CD Pipeline Demo
This is a simple demo of an AWS CI/CD pipeline.
